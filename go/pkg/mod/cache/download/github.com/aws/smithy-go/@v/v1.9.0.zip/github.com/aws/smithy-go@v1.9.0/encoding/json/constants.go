package json

const (
	leftBrace  = '{'
	rightBrace = '}'

	leftBracket  = '['
	rightBracket = ']'

	comma = ','
	quote = '"'
	colon = ':'

	null = "null"
)
