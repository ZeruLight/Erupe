# crt

Package crt provides C-runtime services. (Work In Progress)

Installation

    $ go get modernc.org/crt

Documentation: [godoc.org/modernc.org/crt](http://godoc.org/modernc.org/crt)
