int main() {
	int i;
	i = i && i;
}
