// +build ql

package main

import (
	_ "github.com/golang-migrate/migrate/database/ql"
)
