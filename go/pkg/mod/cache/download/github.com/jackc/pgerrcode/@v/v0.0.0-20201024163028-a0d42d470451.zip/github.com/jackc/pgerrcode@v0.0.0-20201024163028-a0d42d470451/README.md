[![](https://godoc.org/github.com/jackc/pgerrcode?status.svg)](https://godoc.org/github.com/jackc/pgerrcode)

# pgerrcode

Package pgerrcode contains constants for PostgreSQL error codes.

## License

MIT for this package's code and PostgreSQL License for the underlying data.
