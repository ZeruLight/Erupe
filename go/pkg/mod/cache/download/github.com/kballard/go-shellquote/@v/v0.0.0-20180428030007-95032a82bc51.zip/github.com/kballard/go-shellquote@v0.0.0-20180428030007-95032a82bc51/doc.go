// Shellquote provides utilities for joining/splitting strings using sh's
// word-splitting rules.
package shellquote
