CREATE UNIQUE INDEX UsersEmailIndex ON Users (Email)
