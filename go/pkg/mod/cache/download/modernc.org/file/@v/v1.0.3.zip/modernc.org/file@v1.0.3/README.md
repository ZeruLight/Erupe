# file

Package file handles write-ahead logs and space management of os.File-like entities.

## Build status

available at https://modern-c.appspot.com/-/builder/?importpath=modernc.org%2ffile

Installation

    $ go get modernc.org/file

Documentation: [godoc.org/modernc.org/file](http://godoc.org/modernc.org/file)
