// +build spanner

package main

import (
	_ "github.com/golang-migrate/migrate/database/spanner"
)
