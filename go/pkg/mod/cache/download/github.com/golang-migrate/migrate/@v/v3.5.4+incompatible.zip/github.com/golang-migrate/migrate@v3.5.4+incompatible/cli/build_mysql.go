// +build mysql

package main

import (
	_ "github.com/golang-migrate/migrate/database/mysql"
)
