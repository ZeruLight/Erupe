// +build aws_s3

package main

import (
	_ "github.com/golang-migrate/migrate/source/aws_s3"
)
