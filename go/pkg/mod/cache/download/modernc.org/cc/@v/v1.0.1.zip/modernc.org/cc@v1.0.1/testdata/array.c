char a[];

void f() {
	a;
}

char a[] = "foo";
