// Package pgproto3 is a encoder and decoder of the PostgreSQL wire protocol version 3.
package pgproto3
