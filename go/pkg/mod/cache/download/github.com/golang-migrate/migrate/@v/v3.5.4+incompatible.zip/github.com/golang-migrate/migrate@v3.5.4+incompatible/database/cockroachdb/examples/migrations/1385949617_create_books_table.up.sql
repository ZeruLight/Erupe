CREATE TABLE books (
  user_id INT,
  name    STRING(40),
  author  STRING(40)
);
