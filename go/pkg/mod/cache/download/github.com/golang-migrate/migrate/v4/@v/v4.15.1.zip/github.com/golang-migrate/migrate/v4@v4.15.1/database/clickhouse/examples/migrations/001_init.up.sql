CREATE TABLE test_1 (
    Date Date 
) Engine=Memory;