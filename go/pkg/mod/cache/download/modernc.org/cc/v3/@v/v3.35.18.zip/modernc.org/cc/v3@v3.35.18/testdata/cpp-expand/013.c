#define x _Pragma("STDC FP_CONTRACT ON")
x
