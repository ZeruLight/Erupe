# v1.7.4 (2021-12-02)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.7.3 (2021-11-30)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.7.2 (2021-11-19)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.7.1 (2021-11-12)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.7.0 (2021-11-06)

* **Feature**: The SDK now supports configuration of FIPS and DualStack endpoints using environment variables, shared configuration, or programmatically.
* **Feature**: Updated `github.com/aws/smithy-go` to latest version
* **Dependency Update**: Updated to the latest SDK module versions

# v1.6.0 (2021-10-21)

* **Feature**: Updated  to latest version
* **Dependency Update**: Updated to the latest SDK module versions

# v1.5.4 (2021-10-11)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.5.3 (2021-09-17)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.5.2 (2021-09-10)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.5.1 (2021-09-02)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.5.0 (2021-08-27)

* **Feature**: Updated `github.com/aws/smithy-go` to latest version
* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.1 (2021-08-19)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.0 (2021-08-04)

* **Feature**: adds error handling for defered close calls
* **Dependency Update**: Updated `github.com/aws/smithy-go` to latest version.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.2 (2021-07-15)

* **Dependency Update**: Updated `github.com/aws/smithy-go` to latest version
* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.1 (2021-07-01)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.0 (2021-06-25)

* **Feature**: Updated `github.com/aws/smithy-go` to latest version
* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.3 (2021-06-04)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.2 (2021-05-25)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.1 (2021-05-20)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.0 (2021-05-14)

* **Feature**: Constant has been added to modules to enable runtime version inspection for reporting.
* **Dependency Update**: Updated to the latest SDK module versions

