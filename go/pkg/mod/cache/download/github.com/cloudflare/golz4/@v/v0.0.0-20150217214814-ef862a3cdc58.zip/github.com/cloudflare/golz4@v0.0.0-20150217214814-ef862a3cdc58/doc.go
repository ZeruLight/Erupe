// Package lz4 implements compression using lz4.c and lz4hc.c
//
// Copyright (c) 2013 CloudFlare, Inc.
package lz4
