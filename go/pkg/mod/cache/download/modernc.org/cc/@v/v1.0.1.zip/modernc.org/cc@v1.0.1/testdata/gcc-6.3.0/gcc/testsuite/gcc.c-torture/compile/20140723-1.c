double f(double a, double b, int c, int d)
{
  return (c>10&&d>20)?a:b;
}
