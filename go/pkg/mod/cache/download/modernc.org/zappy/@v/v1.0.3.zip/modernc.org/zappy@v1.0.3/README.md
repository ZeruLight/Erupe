zappy
=====

Package zappy implements the zappy block-based compression format.  It aims for
a combination of good speed and reasonable compression.

Installation: $ go get modernc.org/zappy

Documentation: [godoc.org/modernc.org/zappy](http://godoc.org/modernc.org/zappy)
