[![](https://godoc.org/github.com/jackc/chunkreader?status.svg)](https://godoc.org/github.com/jackc/chunkreader)
[![Build Status](https://travis-ci.org/jackc/chunkreader.svg)](https://travis-ci.org/jackc/chunkreader)

# chunkreader

Package chunkreader provides an opinionated, efficient buffered reader.

Extracted from original implementation in https://github.com/jackc/pgx.
