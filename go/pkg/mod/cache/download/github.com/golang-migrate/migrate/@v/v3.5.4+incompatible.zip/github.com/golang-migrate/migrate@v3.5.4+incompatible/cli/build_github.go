// +build github

package main

import (
	_ "github.com/golang-migrate/migrate/source/github"
)
