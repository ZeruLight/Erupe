# v2.0.2 (2021-12-02)

* **Dependency Update**: Updated to the latest SDK module versions

# v2.0.1 (2021-11-19)

* **Dependency Update**: Updated to the latest SDK module versions

# v2.0.0 (2021-11-06)

* **Release**: Endpoint Variant Model Support
* **Feature**: The SDK now supports configuration of FIPS and DualStack endpoints using environment variables, shared configuration, or programmatically.
* **Feature**: Updated `github.com/aws/smithy-go` to latest version
* **Dependency Update**: Updated to the latest SDK module versions

