// +build sqlite3

package main

import (
	_ "github.com/golang-migrate/migrate/database/sqlite3"
)
