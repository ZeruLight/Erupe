int main() {
	int i;
	i = (i ? 1 : 2) && i;
}
