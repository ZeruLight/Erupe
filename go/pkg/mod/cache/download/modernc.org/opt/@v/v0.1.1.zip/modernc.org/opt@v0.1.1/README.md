# opt

Package opt implements command-line flag parsing.

### Installation

    $ go get [-u] modernc.org/opt

### Documentation

[godoc.org/modernc.org/opt](http://godoc.org/modernc.org/opt)
