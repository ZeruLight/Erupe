#include <assert.h>

int main() {
	int i = 0;
	if (i) {
		assert(0);
	}
}
