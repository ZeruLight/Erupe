<img src="logo/ql-dark.svg" alt="ql Logo" height="250">

-----------------

Package ql is a pure Go embedded (S)QL database.

Installation

    $ go get modernc.org/ql

Documentation: [godoc.org/modernc.org/ql](http://godoc.org/modernc.org/ql)

----

Accompanying tool to play with a DB

Installation

    $ go get modernc.org/ql/ql

Documentation: [godoc.org/modernc.org/ql/ql](http://godoc.org/modernc.org/ql/ql)

