# Azure pipelines for go-mssqldb

## Purpose

Created by @shueybubbles, a member of the SQL Server team at Microsoft. I built these pipelines to run tests against specific configurations of SQL Server and Azure SQL Database in our internal Azure Devops subscriptions.

Each YML will be sufficiently parameterized to be runnable in other environments.
