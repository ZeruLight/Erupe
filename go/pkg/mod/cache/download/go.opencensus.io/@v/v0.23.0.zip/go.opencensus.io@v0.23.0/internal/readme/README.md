Use the following commands to regenerate the README.

```bash
$ GO11MODULE=off go get github.com/rakyll/embedmd
$ embedmd -w ../../README.md
```
