DROP TABLE movies;
