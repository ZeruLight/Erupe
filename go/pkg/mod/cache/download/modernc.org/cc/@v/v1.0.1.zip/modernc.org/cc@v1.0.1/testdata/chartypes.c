char c;
signed char d;
unsigned char e;
