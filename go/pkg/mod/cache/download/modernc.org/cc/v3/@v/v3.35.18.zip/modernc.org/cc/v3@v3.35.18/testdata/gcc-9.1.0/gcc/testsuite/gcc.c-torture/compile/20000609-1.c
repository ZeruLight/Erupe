int main ()
{
  char temp[1024] = "tempfile";
  return temp[0] != 't';
}

