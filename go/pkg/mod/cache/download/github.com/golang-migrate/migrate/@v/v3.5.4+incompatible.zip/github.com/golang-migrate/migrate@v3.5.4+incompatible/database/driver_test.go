package database

func ExampleDriver() {
	// see database/stub for an example

	// database/stub/stub.go has the driver implementation
	// database/stub/stub_test.go runs database/testing/test.go:Test
}
