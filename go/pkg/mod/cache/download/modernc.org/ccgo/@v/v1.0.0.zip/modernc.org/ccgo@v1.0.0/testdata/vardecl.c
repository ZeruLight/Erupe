int main() {
	int i0;
	{
		int i0;
		{
			int i0;
			int j0;
		}
		int j0;
	}
	int j0;
}
