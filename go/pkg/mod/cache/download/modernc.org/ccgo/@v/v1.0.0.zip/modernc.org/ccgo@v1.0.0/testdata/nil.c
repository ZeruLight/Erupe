int main() {
	void *p;
	char *q;
	p = 0;
	q = 0;
}
