short int a;

int main (void)
{
  a = 65535.0;
  return 0;
}
