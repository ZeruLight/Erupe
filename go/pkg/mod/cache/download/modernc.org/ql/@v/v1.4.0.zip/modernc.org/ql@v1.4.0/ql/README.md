ql
==

Command ql is a utility to explore a database, prototype a schema or test drive a query, etc.

Installation

    $ go get modernc.org/ql/ql

Documentation: [godoc.org/modernc.org/ql/ql](http://godoc.org/modernc.org/ql/ql)
