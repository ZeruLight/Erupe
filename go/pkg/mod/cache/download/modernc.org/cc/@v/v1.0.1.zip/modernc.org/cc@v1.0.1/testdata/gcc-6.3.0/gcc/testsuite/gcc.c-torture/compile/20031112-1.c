extern __inline int __finite (double __value) { return 0; }
extern __typeof (__finite) __finite __asm__ ("" "__GI___finite");
