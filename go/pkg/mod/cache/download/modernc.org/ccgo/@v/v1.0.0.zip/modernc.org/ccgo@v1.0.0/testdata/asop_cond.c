int main() {
	int i;
	i += i ? i, 1 : 2;
}
