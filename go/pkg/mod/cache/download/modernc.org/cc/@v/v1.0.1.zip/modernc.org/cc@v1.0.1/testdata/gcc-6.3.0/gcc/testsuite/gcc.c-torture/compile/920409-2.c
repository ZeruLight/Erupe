double x(){int x1,x2;double v;
if(((long)(x1-x2))<1)return -1.0;v=t(v);v=y(1,v>0.0?(int)v:((int)v-1));}
