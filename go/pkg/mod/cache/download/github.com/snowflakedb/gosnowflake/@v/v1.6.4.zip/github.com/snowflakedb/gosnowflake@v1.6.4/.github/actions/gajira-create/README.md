# Create a jira issue from a GH issue

Stolen from [gajira-create](https://github.com/atlassian/gajira-create) and modified to support required custom fields in use at snowflake.

Most of the dependencies (gajira-login, etc) have been folded into this action
