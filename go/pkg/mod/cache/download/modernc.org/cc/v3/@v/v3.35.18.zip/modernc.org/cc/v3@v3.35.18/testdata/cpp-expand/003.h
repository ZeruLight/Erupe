#define str(s) # s

str(: @\n)
