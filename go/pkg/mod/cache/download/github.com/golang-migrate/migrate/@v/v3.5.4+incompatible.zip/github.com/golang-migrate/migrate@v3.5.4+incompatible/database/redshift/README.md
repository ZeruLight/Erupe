Redshift
===

This provides a Redshift driver for migrations.  It is used whenever the URL of the database starts with `redshift://`.

Redshift is PostgreSQL compatible but has some specific features (or lack thereof) that require slightly different behavior.
