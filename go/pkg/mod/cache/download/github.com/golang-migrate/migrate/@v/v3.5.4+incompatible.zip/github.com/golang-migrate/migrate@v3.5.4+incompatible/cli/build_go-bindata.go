// +build go_bindata

package main

import (
	_ "github.com/golang-migrate/migrate/source/go_bindata"
)
