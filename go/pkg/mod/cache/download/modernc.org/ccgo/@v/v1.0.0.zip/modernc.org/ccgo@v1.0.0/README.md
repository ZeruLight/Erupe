# ccgo

Package ccgo translates [cc](https://modernc.org/cc/tree/master/v2) ASTs to Go. (Work In Progress)

Installation

    $ go get modernc.org/ccgo

Documentation: [godoc.org/modernc.org/ccgo](http://godoc.org/modernc.org/ccgo)

Changelog

2018-07-01 This package is no longer maintained. Please see the v2 version at

[https://modernc.org/ccgo/tree/master/v2](https://modernc.org/ccgo/tree/master/v2)
