# b

Package b implements a B+tree.

## Build status

available at https://modern-c.appspot.com/-/builder/?importpath=modernc.org%2fb


Installation:

    $ go get modernc.org/b

Documentation: [godoc.org/modernc.org/b](http://godoc.org/modernc.org/b)
