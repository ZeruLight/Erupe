[![](https://godoc.org/github.com/jackc/pgproto3?status.svg)](https://godoc.org/github.com/jackc/pgproto3)
[![Build Status](https://travis-ci.org/jackc/pgproto3.svg)](https://travis-ci.org/jackc/pgproto3)

# pgproto3

Package pgproto3 is a encoder and decoder of the PostgreSQL wire protocol version 3.

Extracted from original implementation in https://github.com/jackc/pgx.
