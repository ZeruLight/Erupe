/* Copyright (C) 2000  Free Software Foundation  */
/* Contributed by Alexandre Oliva <aoliva@cygnus.com> */

enum { foo = sizeof(void *) };
int i = sizeof(void *);
