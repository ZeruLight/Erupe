// +build godoc_vfs

package main

import (
	_ "github.com/golang-migrate/migrate/source/godoc_vfs"
)
