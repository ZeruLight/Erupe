golz4
=====

Golang interface to LZ4 compression
