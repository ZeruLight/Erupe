# Description

This library has been deprecated in favor of `github.com/cncf/xds/go`. All users are recommended to switch their imports.

In the meantime, this library is frozen and has all previously public types aliased to point to `github.com/cncf/xds/go`.