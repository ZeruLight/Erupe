// +build google_cloud_storage

package main

import (
	_ "github.com/golang-migrate/migrate/source/google_cloud_storage"
)
