<xRFC ID>: Title
----
* Author(s): [Author Name, Co-Author Name ...]
* Approver:
* Implemented in: <xDS client, ...>
* Last updated: [YYYY-MM-DD]

## Abstract

[A short summary of the proposal.]

## Background

[An introduction of the necessary background and the problem being solved by the proposed change.]


### Related Proposals:
* A list of proposals this proposal builds on or supersedes.

## Proposal

[A precise statement of the proposed change.]

## Rationale

[A discussion of alternate approaches and the trade offs, advantages, and disadvantages of the specified approach.]


## Implementation

[A description of the steps in the implementation, who will do them, and when.  If a particular client is going to get the implementation first, this section should list the proposed order.]

## Open issues (if applicable)

[A discussion of issues relating to this proposal for which the author does not  know the solution. This section may be omitted if there are none.]
