#define TABSIZE 100
int table[TABSIZE];
