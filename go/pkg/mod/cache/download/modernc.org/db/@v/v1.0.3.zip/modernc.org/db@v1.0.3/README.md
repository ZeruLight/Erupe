# db

Package DB implements some data structures found in database implementations. (Work in Progress)

## Build status

available at https://modern-c.appspot.com/-/builder/?importpath=modernc.org%2fdb

Installation

    $ go get modernc.org/db

Documentation: [godoc.org/modernc.org/db](http://godoc.org/modernc.org/db)
