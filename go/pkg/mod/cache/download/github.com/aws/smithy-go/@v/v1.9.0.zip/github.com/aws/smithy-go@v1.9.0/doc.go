// Package smithy provides the core components for a Smithy SDK.
package smithy
