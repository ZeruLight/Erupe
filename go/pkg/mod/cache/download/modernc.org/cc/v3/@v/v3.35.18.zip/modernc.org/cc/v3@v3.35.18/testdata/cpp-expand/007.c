#define a(b) b
#define c a
c(42)
