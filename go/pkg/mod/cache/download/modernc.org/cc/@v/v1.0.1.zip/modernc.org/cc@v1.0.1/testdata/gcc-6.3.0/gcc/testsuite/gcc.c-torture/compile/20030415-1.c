float g(float f)
{
  return fabs(f);
}
