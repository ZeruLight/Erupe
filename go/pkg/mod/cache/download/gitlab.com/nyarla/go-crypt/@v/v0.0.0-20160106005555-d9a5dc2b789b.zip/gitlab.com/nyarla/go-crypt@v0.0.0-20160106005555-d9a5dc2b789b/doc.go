// Package crypt is a implementation of crypt(3) by golang.
//
// This is a fork of iasija's orignal implementation.
//
// Orignal soruce code Copyrights (C) iasija All rights reserved,
// and original source code is under the 3-Clause BSD.
//
// Modification codes for supporting latest golang and added test codes are
// Copyright (c) 2013-2014 Naoki OKAMURA <nyarla@thotep.net>,
// and modifiration code and test codes are under same as the orignal source code license. (3-Clause BSD)
package crypt
