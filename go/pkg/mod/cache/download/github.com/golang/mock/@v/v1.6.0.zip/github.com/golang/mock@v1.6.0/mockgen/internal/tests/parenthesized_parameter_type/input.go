package parenthesized_parameter_type

type Example interface {
	ParenthesizedParameterType(param *(int))
}
